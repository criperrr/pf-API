export type ApiToken = {
    id_Token: number;
    id_User: number;
    id_NsacAccount: number;
    cookieString: string;
    token: string;
};
