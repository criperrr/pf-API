export type NsacAccount = {
    id_NsacAccount?: number,
    email: string;
    password: string;
}
